package gym;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class equipmentShow1
 */
@WebServlet("/equipmentShow1")
public class equipmentShow1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public equipmentShow1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
			try {
				
				
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con=DBConnection.getConnection();
				Statement pst=con.createStatement();
				ResultSet rs=pst.executeQuery("select * from equipment");
				
			while(rs.next()) {
				out.println("<html><style>body {background-color: lightblue;}</style><body>");
				out.println("<h3>Equipment Id: "+rs.getInt(1)+"&nbsp;&nbsp&nbsp;&nbsp;");
				out.println("Equipment Name: "+rs.getString(2)+"&nbsp;&nbsp;&nbsp;&nbsp");
				out.println("Contact No.: "+rs.getLong(3)+"&nbsp;&nbsp;&nbsp;&nbsp");
				out.println("Description: "+rs.getString(5)+"&nbsp;&nbsp;&nbsp;&nbsp");
				out.println("Vendor: "+rs.getString(7)+"&nbsp;&nbsp;&nbsp;&nbsp");
				out.println("Amount: "+rs.getDouble(4)+"&nbsp;&nbsp;&nbsp;&nbsp");
				out.println("Date: "+rs.getString(6)+"</h3>\n");
			}
			
			pst.close();
				con.close();
			}
			
			catch(Exception e) {
				e.printStackTrace();
			}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
