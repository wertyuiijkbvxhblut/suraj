package gym;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class forgetS
 */
@WebServlet("/forgetS")
public class forgetS extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public forgetS() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String n=request.getParameter("name");
		String p=request.getParameter("pass");
if(n.isEmpty() || p.isEmpty()) {
	out.println("<html><body><center>Please fill form properly..</center></body></html>");
			RequestDispatcher rd=request.getRequestDispatcher("forget.jsp");
			rd.include(request, response);
			
		}else {
		
		try {
			Connection con=null;
			Class.forName("com.mysql.cj.jdbc.Driver");
		     con=DriverManager.getConnection("jdbc:mysql://localhost:3308/gym1","root","");
			Statement stm =  con.createStatement();
			int s=stm.executeUpdate("update log set pass='"+p+"' where uname='"+n+"'");
			if(s!=0) {
				out.println("<html><body><center>password successfully updated..</center></body></html>");
				request.getRequestDispatcher("forget.jsp").include(request, response);
			}
			else {
				out.println("<html><body><center>Username is wrong ..</center></body></html>");
				request.getRequestDispatcher("forget.jsp").include(request, response);
			}
		
		}catch(SQLException e) {
			out.println(e);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	
		
	}

}
