package gym;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class onsiteshow1
 */
@WebServlet("/onsiteshow1")
public class onsiteshow1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public onsiteshow1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
			try {
				
				
				
				Connection con=DBConnection.getConnection();
				Statement pst=con.createStatement();
				ResultSet rs=pst.executeQuery("select * from joinm");
				
			while(rs.next()) {
				out.println("<html><style>body {background-color: coral;}</style><body>");
				out.println("<h3>UserName: "+rs.getString(1)+"&nbsp;&nbsp&nbsp;&nbsp;");
				out.println("Contact No.: "+rs.getLong(2)+"&nbsp;&nbsp;&nbsp;&nbsp");
				out.println("Email: "+rs.getString(3)+"&nbsp;&nbsp;&nbsp;&nbsp");
				out.println("Address: "+rs.getString(4)+"&nbsp;&nbsp;&nbsp;&nbsp");
				out.println("Service: "+rs.getString(5)+"&nbsp;&nbsp;&nbsp;&nbsp");
				out.println("Date: "+rs.getString(6)+"</h3>\n");
			}
			
			pst.close();
				con.close();
			}
			
			catch(Exception e) {
				e.printStackTrace();
			}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
