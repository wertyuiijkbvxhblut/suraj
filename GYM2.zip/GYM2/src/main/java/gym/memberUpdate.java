package gym;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class memberUpdate
 */
@WebServlet("/memberUpdate")
public class memberUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public memberUpdate() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		
		String id=request.getParameter("i");
		String fname=request.getParameter("uname");
		String cont=request.getParameter("con");
		String address=request.getParameter("ad");
		String amount=request.getParameter("Am");
		String servi=request.getParameter("servi");
		String date=request.getParameter("date");
		
		
		if(id.isEmpty() || fname.isEmpty() || cont.isEmpty() || address.isEmpty() ||  servi.isEmpty() || date.isEmpty()) {
			out.println("<html><body><center>Please fill form properly..</center></body></html>");
			RequestDispatcher rd=request.getRequestDispatcher("memberUp.jsp");
			rd.include(request, response);
			
		}else {
			try {
				char c=fname.charAt(0);
				if(c>='a' && c<='z' || c>='A' && c<='Z') {
				Integer idd=Integer.parseInt(id);
				double amo=Double.parseDouble(amount);
				Long Co=Long.parseLong(cont);
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con=DBConnection.getConnection();
				Statement pst=con.createStatement();
				int st =pst.executeUpdate("update gym1.member set ContactNo='"+Co+"',addr='"+address+"',Amount='"+amo+"',Service='"+servi+"',Date='"+date+"' where Id='"+idd+"' &&  Name='"+fname+"' ");
			if(st!=0) {
				out.println("<html><body><center>Updated successfully..</center></body></html>");
				request.getRequestDispatcher("memberUp.jsp").include(request, response);
			}else {
				out.println("<html><body><center>MemberId does not exist..</center></body></html>");
				request.getRequestDispatcher("memberUp.jsp").include(request, response);
			}
				pst.close();
				con.close();
				}else {
					out.println("<html><body><center>Please fill name properly..</center></body></html>");
					request.getRequestDispatcher("memberUp.jsp").include(request, response);
				}
			}catch(SQLIntegrityConstraintViolationException S) {
				out.println("<html><body><center>memberID or fullname already taken..</center></body></html>");
				request.getRequestDispatcher("memberUp.jsp").include(request, response);
			}catch(NumberFormatException N) {
				out.println("<html><body><center>Please fill Id or fullname properly..</center></body></html>");
				request.getRequestDispatcher("memberUp.jsp").include(request, response);
			}
			
			catch(Exception e) {
				e.printStackTrace();
			}
			
		}
		
	}

}
