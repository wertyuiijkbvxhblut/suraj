package gym;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class staffShow
 */
@WebServlet("/staffShow")
public class staffShow extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public staffShow() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		
		String id=request.getParameter("i");
		
		
		if(id.isEmpty()) {
			out.println("<html><body><center>Please fill form properly..</center></body></html>");
			RequestDispatcher rd=request.getRequestDispatcher("staffSho.jsp");
			rd.include(request, response);
			
		}else {
			try {
				Integer idd=Integer.parseInt(id);
				
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con=DBConnection.getConnection();
				Statement pst=con.createStatement();
				ResultSet rs=pst.executeQuery("select * from gym1.staff  where Sid='"+idd+"'");
				
			if(rs.next()) {
				out.println("<html><style>body {background-color: lightblue;}</style><body>");
				out.println("<h3>Member Id: "+rs.getInt(1)+"&nbsp;&nbsp&nbsp;&nbsp;");
				out.println("Full Name: "+rs.getString(2)+"&nbsp;&nbsp;&nbsp;&nbsp");
				out.println("Contact No.: "+rs.getLong(3)+"&nbsp;&nbsp;&nbsp;&nbsp");
				out.println("Address: "+rs.getString(4)+"&nbsp;&nbsp;&nbsp;&nbsp");
				out.println("Designation: "+rs.getString(5)+"&nbsp;&nbsp;&nbsp;&nbsp");
				out.println("Salary: "+rs.getDouble(6)+"&nbsp;&nbsp;&nbsp;&nbsp");
				out.println("Date: "+rs.getString(7)+"</h3>\n");
				
			}else {
				out.println("<html><body><center>MemberId does not exist..</center></body></html>");
				request.getRequestDispatcher("staffSho.jsp").include(request, response);
			}
				pst.close();
				con.close();
			}catch(SQLIntegrityConstraintViolationException S) {
				out.println("<html><body><center>memberID or fullname already taken..</center></body></html>");
				request.getRequestDispatcher("staffSho.jsp").include(request, response);
			}
			
			catch(Exception e) {
				e.printStackTrace();
			}
			
		}
		
	}

}
