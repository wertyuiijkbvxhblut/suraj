package gym;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class staffDelete
 */
@WebServlet("/staffDelete")
public class staffDelete extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public staffDelete() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		
		String id=request.getParameter("i");
		
		
		if(id.isEmpty()) {
			out.println("<html><body><center>Please fill form properly..</center></body></html>");
			RequestDispatcher rd=request.getRequestDispatcher("staffDel.jsp");
			rd.include(request, response);
			
		}else {
			try {
				Integer idd=Integer.parseInt(id);
				
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con=DBConnection.getConnection();
				Statement pst=con.createStatement();
				int st =pst.executeUpdate("delete from gym1.staff  where Sid='"+idd+"'");
			if(st!=0) {
				out.println("<html><body><center>Deleted successfully..</center></body></html>");
				request.getRequestDispatcher("staffDel.jsp").include(request, response);
			}else {
				out.println("<html><body><center>StaffId does not exist..</center></body></html>");
				request.getRequestDispatcher("staffDel.jsp").include(request, response);
			}
				pst.close();
				con.close();
			}catch(SQLIntegrityConstraintViolationException S) {
				out.println("<html><body><center>StaffId or fullname already taken..</center></body></html>");
				request.getRequestDispatcher("staffDel.jsp").include(request, response);
			}catch(NumberFormatException N) {
				out.println("<html><body><center>Please fill Id or fullname properly..</center></body></html>");
				request.getRequestDispatcher("staffDel.jsp").include(request, response);
			}
			
			catch(Exception e) {
				e.printStackTrace();
			}
			
		}
		
	}

}
